# Personal Finance Tracker (Backend)

NestJS + Prisma backend with Auth, Users, Transactions, Budgets, Reports, Goals, Notifications.

## Quick start
```bash
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run prisma:seed
npm run start:dev
```
The API listens on `http://localhost:3000`.

Use the seeded user to login:
- email: `admin@example.com`
- password: `password123`
