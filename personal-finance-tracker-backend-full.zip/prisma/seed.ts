import { PrismaClient } from "@prisma/client";
import * as bcrypt from "bcrypt";

const prisma = new PrismaClient();

async function main() {
  const hashed = await bcrypt.hash("password123", 10);
  const user = await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: {
      email: "admin@example.com",
      password: hashed,
    },
  });

  await prisma.transaction.createMany({
    data: [
      { description: "Salary", amount: 5000, date: new Date(), userId: user.id },
      { description: "Groceries", amount: -120.5, date: new Date(), userId: user.id },
    ]
  });

  await prisma.budget.create({
    data: {
      category: "Food",
      amount: 400,
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)),
      userId: user.id
    }
  });

  await prisma.goal.create({
    data: {
      name: "Emergency Fund",
      targetAmount: 10000,
      currentAmount: 1500,
      deadline: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
      userId: user.id
    }
  });

  await prisma.notification.create({
    data: {
      userId: user.id,
      message: "Welcome to Personal Finance Tracker!"
    }
  });

  console.log("Seed completed with user:", user.email);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
