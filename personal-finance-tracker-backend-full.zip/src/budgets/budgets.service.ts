import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { CreateBudgetDto } from "./dto/create-budget.dto";
import { UpdateBudgetDto } from "./dto/update-budget.dto";

@Injectable()
export class BudgetsService {
  constructor(private prisma: PrismaService) {}

  async create(createBudgetDto: CreateBudgetDto) {
    const { category, amount, startDate, endDate, userId } = createBudgetDto;
    return this.prisma.budget.create({
      data: {
        category,
        amount,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        userId,
      },
    });
  }

  async findAll() {
    return this.prisma.budget.findMany();
  }

  async findOne(id: string) {
    return this.prisma.budget.findUnique({ where: { id } });
  }

  async update(id: string, updateBudgetDto: UpdateBudgetDto) {
    const data: any = { ...updateBudgetDto };
    if (updateBudgetDto.startDate) data.startDate = new Date(updateBudgetDto.startDate);
    if (updateBudgetDto.endDate) data.endDate = new Date(updateBudgetDto.endDate);
    return this.prisma.budget.update({
      where: { id },
      data,
    });
  }

  async remove(id: string) {
    return this.prisma.budget.delete({ where: { id } });
  }
}
