export class CreateBudgetDto {
  category: string;
  amount: number;
  startDate: string;
  endDate: string;
  userId: string;
}
