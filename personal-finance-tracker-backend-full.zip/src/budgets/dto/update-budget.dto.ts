export class UpdateBudgetDto {
  category?: string;
  amount?: number;
  startDate?: string;
  endDate?: string;
}
