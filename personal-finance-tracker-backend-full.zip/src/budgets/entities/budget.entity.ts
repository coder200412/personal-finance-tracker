import { User } from "../../users/entities/user.entity";

export class Budget {
  id: string;
  category: string;
  amount: number;
  startDate: Date;
  endDate: Date;
  userId: string;
  user: User;
}
