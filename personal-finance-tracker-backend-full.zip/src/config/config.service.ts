import { Injectable } from "@nestjs/common";
import * as dotenv from "dotenv";

dotenv.config();

@Injectable()
export class ConfigService {
  get(key: string): string {
    return process.env[key] as string;
  }

  getDatabaseUrl(): string {
    return this.get("DATABASE_URL");
  }

  getJwtSecret(): string {
    return this.get("JWT_SECRET");
  }

  getPort(): number {
    return parseInt(this.get("PORT") || "3000", 10);
  }
}
