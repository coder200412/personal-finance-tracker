export class CreateGoalDto {
  userId: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: Date;
}
