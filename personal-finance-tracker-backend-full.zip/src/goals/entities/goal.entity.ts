import { User } from "../../users/entities/user.entity";

export class Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: Date;
  userId: string;
  user: User;
}
