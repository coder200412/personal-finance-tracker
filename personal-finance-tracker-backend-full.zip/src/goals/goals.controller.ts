import { Controller, Get, Post, Patch, Delete, Param, Body, UseGuards, Query } from "@nestjs/common";
import { GoalsService } from "./goals.service";
import { CreateGoalDto } from "./dto/create-goal.dto";
import { UpdateGoalDto } from "./dto/update-goal.dto";
import { JwtAuthGuard } from "../auth/jwt-auth.guard";

@Controller("goals")
@UseGuards(JwtAuthGuard)
export class GoalsController {
  constructor(private readonly goalsService: GoalsService) {}

  @Post()
  async create(@Body() createGoalDto: CreateGoalDto) {
    return this.goalsService.create(createGoalDto);
  }

  @Get()
  async findAll(@Query("userId") userId: string) {
    return this.goalsService.findAll(userId);
  }

  @Patch(":id")
  async update(@Param("id") id: string, @Body() updateGoalDto: UpdateGoalDto) {
    return this.goalsService.update(id, updateGoalDto);
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return this.goalsService.remove(id);
  }
}
