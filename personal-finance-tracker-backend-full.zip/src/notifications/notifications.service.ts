import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class NotificationsService {
  constructor(private prisma: PrismaService) {}

  async sendNotification(userId: string, message: string) {
    // In a real app, integrate with Email/SMS/Push providers here.
    return this.prisma.notification.create({
      data: { userId, message },
    });
  }
}
