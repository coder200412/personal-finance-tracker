import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  async generateSummaryReport(userId: string) {
    const totalIncome = await this.prisma.transaction.aggregate({
      where: { userId, amount: { gt: 0 } },
      _sum: { amount: true },
    });

    const totalExpenses = await this.prisma.transaction.aggregate({
      where: { userId, amount: { lt: 0 } },
      _sum: { amount: true },
    });

    return {
      totalIncome: totalIncome._sum.amount || 0,
      totalExpenses: totalExpenses._sum.amount || 0,
      netIncome: (totalIncome._sum.amount || 0) + (totalExpenses._sum.amount || 0),
    };
  }

  async generateMonthlyReport(userId: string, month: string) {
    const startDate = new Date(`${month}-01`);
    const endDate = new Date(`${month}-31`);

    const monthlyIncome = await this.prisma.transaction.aggregate({
      where: {
        userId,
        amount: { gt: 0 },
        date: { gte: startDate, lte: endDate },
      },
      _sum: { amount: true },
    });

    const monthlyExpenses = await this.prisma.transaction.aggregate({
      where: {
        userId,
        amount: { lt: 0 },
        date: { gte: startDate, lte: endDate },
      },
      _sum: { amount: true },
    });

    return {
      monthlyIncome: monthlyIncome._sum.amount || 0,
      monthlyExpenses: monthlyExpenses._sum.amount || 0,
      netIncome: (monthlyIncome._sum.amount || 0) + (monthlyExpenses._sum.amount || 0),
    };
  }
}
