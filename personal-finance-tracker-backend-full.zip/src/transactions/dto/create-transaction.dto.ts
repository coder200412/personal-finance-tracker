export class CreateTransactionDto {
  description: string;
  amount: number;
  date: string;
  userId: string;
}
