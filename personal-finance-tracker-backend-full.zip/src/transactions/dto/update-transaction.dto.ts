export class UpdateTransactionDto {
  description?: string;
  amount?: number;
  date?: string;
}
