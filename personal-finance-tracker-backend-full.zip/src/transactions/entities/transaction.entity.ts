import { User } from "../../users/entities/user.entity";

export class Transaction {
  id: string;
  description: string;
  amount: number;
  date: Date;
  userId: string;
  user: User;
}
