import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { CreateTransactionDto } from "./dto/create-transaction.dto";
import { UpdateTransactionDto } from "./dto/update-transaction.dto";

@Injectable()
export class TransactionsService {
  constructor(private prisma: PrismaService) {}

  async create(createTransactionDto: CreateTransactionDto) {
    const { description, amount, date, userId } = createTransactionDto;
    return this.prisma.transaction.create({
      data: {
        description,
        amount,
        date: new Date(date),
        userId,
      },
    });
  }

  async findAll() {
    return this.prisma.transaction.findMany();
  }

  async findOne(id: string) {
    return this.prisma.transaction.findUnique({ where: { id } });
  }

  async update(id: string, updateTransactionDto: UpdateTransactionDto) {
    const data: any = { ...updateTransactionDto };
    if (updateTransactionDto.date) data.date = new Date(updateTransactionDto.date);
    return this.prisma.transaction.update({
      where: { id },
      data,
    });
  }

  async remove(id: string) {
    return this.prisma.transaction.delete({ where: { id } });
  }
}
