describe('AuthController', () => {
  it('should be defined', () => {
    expect(true).toBeTruthy();
  });
});
