describe('TransactionsController', () => {
  it('should be defined', () => {
    expect(true).toBeTruthy();
  });
});
