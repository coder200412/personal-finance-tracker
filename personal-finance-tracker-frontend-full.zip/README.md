# Personal Finance Tracker — Frontend

Next.js (Pages Router) + TypeScript + TailwindCSS + Redux Toolkit + Chart.js

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:3000