import './globals.css';
import { ReactNode } from 'react';
import { Providers } from '../redux/Providers';

export const metadata = {
  title: 'Personal Finance Tracker',
  description: 'Track your personal finances easily',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}