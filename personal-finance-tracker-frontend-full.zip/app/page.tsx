export default function HomePage() {
  return (
    <div className="flex items-center justify-center h-screen">
      <h1 className="text-3xl font-bold">Welcome to Personal Finance Tracker</h1>
    </div>
  );
}