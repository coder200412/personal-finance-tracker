import Link from 'next/link';

export default function Sidebar() {
  return (
    <div className="w-64 h-screen bg-gray-200 p-4">
      <h2 className="font-bold text-lg mb-4">Finance Tracker</h2>
      <ul>
        <li><Link href="/dashboard">Dashboard</Link></li>
        <li><Link href="/transactions">Transactions</Link></li>
      </ul>
    </div>
  );
}