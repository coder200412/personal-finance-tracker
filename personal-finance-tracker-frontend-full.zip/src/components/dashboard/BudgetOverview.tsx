const BudgetOverview = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-4">Budget Overview</h2>
      <p>Total Budget: $5,000</p>
      <p>Total Spent: $2,500</p>
      <p>Remaining: $2,500</p>
    </div>
  );
};

export default BudgetOverview;