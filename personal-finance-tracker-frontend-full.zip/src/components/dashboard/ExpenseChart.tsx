import { Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

const ExpenseChart = () => {
  const data = {
    labels: ["Rent", "Groceries", "Entertainment", "Transport", "Miscellaneous"],
    datasets: [
      {
        label: "Expenses",
        data: [1200, 300, 200, 150, 50],
        backgroundColor: [
          "#f87171",
          "#60a5fa",
          "#fbbf24",
          "#34d399",
          "#f472b6",
        ],
      },
    ],
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-4">Expense Breakdown</h2>
      <Pie data={data} />
    </div>
  );
};

export default ExpenseChart;