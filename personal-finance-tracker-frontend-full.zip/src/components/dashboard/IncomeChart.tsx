import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js';

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const IncomeChart = () => {
  const data = {
    labels: ["Salary", "Freelance", "Investments"],
    datasets: [
      {
        label: "Income",
        data: [4000, 1000, 500],
        backgroundColor: "#4ade80",
      },
    ],
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-4">Income Overview</h2>
      <Bar data={data} />
    </div>
  );
};

export default IncomeChart;