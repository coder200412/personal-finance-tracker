const TransactionTable = () => {
  const transactions = [
    { id: 1, description: "Groceries", amount: -50, date: "2024-10-01" },
    { id: 2, description: "Salary", amount: 500, date: "2024-10-02" },
    { id: 3, description: "Netflix Subscription", amount: -12, date: "2024-10-03" },
  ];

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b">Description</th>
            <th className="py-2 px-4 border-b">Amount</th>
            <th className="py-2 px-4 border-b">Date</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((transaction) => (
            <tr key={transaction.id}>
              <td className="py-2 px-4 border-b">{transaction.description}</td>
              <td className={`py-2 px-4 border-b ${transaction.amount < 0 ? "text-red-500" : "text-green-500"}`}>
                {transaction.amount < 0 ? "-" : "+"}${Math.abs(transaction.amount)}
              </td>
              <td className="py-2 px-4 border-b">{transaction.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TransactionTable;