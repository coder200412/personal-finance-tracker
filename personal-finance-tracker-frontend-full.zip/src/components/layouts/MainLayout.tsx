import { ReactNode } from "react";

interface MainLayoutProps {
  children: ReactNode;
}

const MainLayout = ({ children }: MainLayoutProps) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-blue-600 text-white p-4">
        <h1 className="text-2xl">Personal Finance Tracker</h1>
      </header>
      <main className="flex-grow bg-gray-100 p-6">{children}</main>
      <footer className="bg-blue-600 text-white p-4 text-center">
        <p>&copy; 2024 Personal Finance Tracker</p>
      </footer>
    </div>
  );
};

export default MainLayout;