interface BudgetAlertProps {
  message: string;
  onClose: () => void;
}

const BudgetAlert = ({ message, onClose }: BudgetAlertProps) => {
  return (
    <div className="fixed top-4 right-4 bg-red-500 text-white p-4 rounded-lg shadow-lg">
      <p>{message}</p>
      <button
        className="text-white ml-4"
        onClick={onClose}
        aria-label="Close"
      >
        &times;
      </button>
    </div>
  );
};

export default BudgetAlert;