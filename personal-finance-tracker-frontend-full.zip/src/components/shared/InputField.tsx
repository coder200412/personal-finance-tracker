interface InputFieldProps {
  label: string;
  type: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const InputField = ({ label, type, value, onChange }: InputFieldProps) => {
  return (
    <div className="mb-4">
      <label className="block text-gray-700">{label}</label>
      <input
        type={type}
        className="w-full mt-2 p-2 border border-gray-300 rounded"
        value={value}
        onChange={onChange}
      />
    </div>
  );
};

export default InputField;