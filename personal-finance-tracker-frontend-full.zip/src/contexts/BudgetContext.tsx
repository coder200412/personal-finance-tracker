import { createContext, useContext, useState, ReactNode } from "react";

interface Budget {
  id: string;
  category: string;
  amount: number;
  startDate: string;
  endDate: string;
}

interface BudgetContextType {
  budgets: Budget[];
  addBudget: (budget: Budget) => void;
  removeBudget: (id: string) => void;
}

const BudgetContext = createContext<BudgetContextType | undefined>(undefined);

export const BudgetProvider = ({ children }: { children: ReactNode }) => {
  const [budgets, setBudgets] = useState<Budget[]>([]);

  const addBudget = (budget: Budget) => {
    setBudgets((prev) => [...prev, budget]);
  };

  const removeBudget = (id: string) => {
    setBudgets((prev) => prev.filter((b) => b.id != id));
  };

  return (
    <BudgetContext.Provider value={{ budgets, addBudget, removeBudget }}>
      {children}
    </BudgetContext.Provider>
  );
};

export const useBudgetsContext = () => {
  const ctx = useContext(BudgetContext);
  if (!ctx) throw new Error("useBudgets must be used within a BudgetProvider");
  return ctx;
};