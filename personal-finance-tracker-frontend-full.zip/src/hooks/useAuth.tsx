import { useAuth as useAuthContext } from "../contexts/AuthContext";

export const useAuth = () => {
  const { user, login, logout } = useAuthContext();

  const handleLogin = async (email: string, password: string) => {
    try {
      await login(email, password);
    } catch (error) {
      console.error("Login failed", error);
      throw error;
    }
  };

  const handleLogout = () => {
    logout();
  };

  return { user, handleLogin, handleLogout };
};