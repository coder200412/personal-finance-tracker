import { useBudgetsContext } from "../contexts/BudgetContext";

export const useBudgets = () => {
  const { budgets, addBudget, removeBudget } = useBudgetsContext();

  const handleAddBudget = (category: string, amount: number, startDate: string, endDate: string) => {
    const newBudget = { id: Date.now().toString(), category, amount, startDate, endDate };
    addBudget(newBudget);
  };

  const handleRemoveBudget = (id: string) => {
    removeBudget(id);
  };

  return { budgets, handleAddBudget, handleRemoveBudget };
};