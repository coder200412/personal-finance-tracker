import { useState } from "react";

interface Transaction {
  id: string;
  description: string;
  amount: number;
  date: string;
  type: "income" | "expense";
}

export const useTransactions = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const addTransaction = (transaction: Transaction) => {
    setTransactions((prev) => [...prev, transaction]);
  };

  const removeTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const fetchTransactions = () => {
    const mockTransactions: Transaction[] = [
      { id: "1", description: "Groceries", amount: -50, date: "2024-10-01", type: "expense" },
      { id: "2", description: "Salary", amount: 500, date: "2024-10-02", type: "income" },
      { id: "3", description: "Netflix", amount: -12, date: "2024-10-03", type: "expense" },
    ];
    setTransactions(mockTransactions);
  };

  return { transactions, addTransaction, removeTransaction, fetchTransactions };
};