import type { AppProps } from "next/app";
import { Provider } from "react-redux";
import store from "../store";
import { AuthProvider } from "../contexts/AuthContext";
import { BudgetProvider } from "../contexts/BudgetContext";
import "../styles/globals.css";

export default function MyApp({ Component, pageProps }: AppProps) {
  return (
    <Provider store={store}>
      <AuthProvider>
        <BudgetProvider>
          <Component {...pageProps} />
        </BudgetProvider>
      </AuthProvider>
    </Provider>
  );
}