import BudgetForm from "../../components/forms/BudgetForm";

const CreateBudgetPage = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Create Budget</h1>
      <BudgetForm />
    </div>
  );
};

export default CreateBudgetPage;