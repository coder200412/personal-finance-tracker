const BudgetsPage = () => {
  const budgets = [
    { id: 1, category: "Groceries", amount: 300 },
    { id: 2, category: "Entertainment", amount: 100 },
  ];

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Budgets</h1>
      <ul>
        {budgets.map((budget) => (
          <li key={budget.id} className="mb-4 p-4 bg-white rounded-lg shadow-lg">
            <p>Category: {budget.category}</p>
            <p>Amount: ${budget.amount}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BudgetsPage;