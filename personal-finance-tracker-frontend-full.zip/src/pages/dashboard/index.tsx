import BudgetOverview from "../../components/dashboard/BudgetOverview";
import TransactionTable from "../../components/dashboard/TransactionTable";
import ExpenseChart from "../../components/dashboard/ExpenseChart";
import IncomeChart from "../../components/dashboard/IncomeChart";

const DashboardPage = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <BudgetOverview />
        <ExpenseChart />
        <IncomeChart />
      </div>
      <TransactionTable />
    </div>
  );
};

export default DashboardPage;