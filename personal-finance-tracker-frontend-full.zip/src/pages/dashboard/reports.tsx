const ReportsPage = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Reports</h1>
      <p>Here you can view detailed financial reports and analysis.</p>
    </div>
  );
};

export default ReportsPage;