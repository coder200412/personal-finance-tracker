import { useState } from "react";

const CreateGoalPage = () => {
  const [goal, setGoal] = useState("");
  const [amount, setAmount] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // handle goal creation logic
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Create Financial Goal</h1>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
        <div className="mb-4">
          <label className="block text-gray-700">Goal</label>
          <input
            type="text"
            className="w-full mt-2 p-2 border border-gray-300 rounded"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Amount</label>
          <input
            type="number"
            className="w-full mt-2 p-2 border border-gray-300 rounded"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
        <button type="submit" className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition">
          Create Goal
        </button>
      </form>
    </div>
  );
};

export default CreateGoalPage;