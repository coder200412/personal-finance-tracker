const GoalsPage = () => {
  const goals = [
    { id: 1, name: "Save for a new car", amount: 5000 },
    { id: 2, name: "Emergency Fund", amount: 1000 },
  ];

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Financial Goals</h1>
      <ul>
        {goals.map((goal) => (
          <li key={goal.id} className="mb-4 p-4 bg-white rounded-lg shadow-lg">
            <p>{goal.name}</p>
            <p>Target Amount: ${goal.amount}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default GoalsPage;