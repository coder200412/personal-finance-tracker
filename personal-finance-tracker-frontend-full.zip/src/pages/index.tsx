import Link from "next/link";

const HomePage = () => {
  return (
    <div className="h-screen flex flex-col justify-center items-center bg-gray-100">
      <h1 className="text-4xl font-bold mb-6">Welcome to Personal Finance Tracker</h1>
      <div className="space-x-4">
        <Link href="/auth/login" legacyBehavior>
          <a className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition">
            Login
          </a>
        </Link>
        <Link href="/auth/register" legacyBehavior>
          <a className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition">
            Register
          </a>
        </Link>
      </div>
    </div>
  );
};

export default HomePage;