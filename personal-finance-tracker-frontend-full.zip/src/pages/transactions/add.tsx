import AddTransactionForm from "../../components/forms/AddTransactionForm";

const AddTransactionPage = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Add Transaction</h1>
      <AddTransactionForm />
    </div>
  );
};

export default AddTransactionPage;