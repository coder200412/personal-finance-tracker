const TransactionsPage = () => {
  const transactions = [
    { id: 1, description: "Groceries", amount: -50, date: "2024-10-01" },
    { id: 2, description: "Salary", amount: 500, date: "2024-10-02" },
  ];

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold mb-6">Transactions</h1>
      <ul>
        {transactions.map((transaction) => (
          <li key={transaction.id} className="mb-4 p-4 bg-white rounded-lg shadow-lg">
            <p>{transaction.description}</p>
            <p>Amount: ${transaction.amount}</p>
            <p>Date: {transaction.date}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TransactionsPage;