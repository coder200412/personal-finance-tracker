import axios from "axios";

const API_URL = "/api/budgets";

export const getBudgets = async () => {
  const response = await axios.get(API_URL);
  return response.data;
};

export const createBudget = async (budget: any) => {
  const response = await axios.post(API_URL, budget);
  return response.data;
};

export const deleteBudget = async (id: string) => {
  const response = await axios.delete(`${API_URL}/${id}`);
  return response.data;
};