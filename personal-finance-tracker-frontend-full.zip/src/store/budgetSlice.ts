import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { createBudget, getBudgets } from "../services/budgetService";

interface BudgetState {
  budgets: any[];
  loading: boolean;
  error: string | null;
}

const initialState: BudgetState = {
  budgets: [],
  loading: false,
  error: null,
};

export const fetchBudgets = createAsyncThunk("budgets/fetch", async () => {
  const response = await getBudgets();
  return response;
});

export const addBudget = createAsyncThunk(
  "budgets/add",
  async (budget: any, thunkAPI) => {
    try {
      const response = await createBudget(budget);
      return response;
    } catch (error) {
      return thunkAPI.rejectWithValue("Failed to create budget");
    }
  }
);

const budgetSlice = createSlice({
  name: "budgets",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchBudgets.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchBudgets.fulfilled, (state, action) => {
        state.budgets = action.payload;
        state.loading = false;
      })
      .addCase(fetchBudgets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default budgetSlice.reducer;