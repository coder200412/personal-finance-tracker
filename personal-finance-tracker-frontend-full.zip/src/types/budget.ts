export interface Budget {
  id: string;
  category: string;
  amount: number;
  startDate: string;
  endDate: string;
}