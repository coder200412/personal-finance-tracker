export const BUDGET_CATEGORIES = [
  "Groceries",
  "Entertainment",
  "Transportation",
  "Housing",
  "Healthcare",
  "Savings",
];