export const validateForm = (fields: { [key: string]: string }) => {
  const errors: { [key: string]: string } = {};

  for (const key in fields) {
    if (!fields[key]) {
      errors[key] = `${key} is required`;
    }
  }

  return errors;
};